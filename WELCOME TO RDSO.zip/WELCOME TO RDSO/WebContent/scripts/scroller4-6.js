
divtextb ="<div id=d";
divtev1=" onmouseover=\"mdivmo(";
divtev2=")\" onmouseout =\"restime(";
divtev3=")\" onclick=\"butclick(";
divtev4=")\"";
divtexts = " style=\"position:absolute;visibility:hidden;width:"+tmpv+"; COLOR: black; left:0; top:0; FONT-FAMILY: tahoma; FONT-SIZE: 8pt; FONT-STYLE: normal; FONT-WEIGHT: bold; TEXT-DECORATION: none; margin:0px; LINE-HEIGHT: 10pt; text-align:justify;padding:0px;\">";
ns6span= " style=\"position:relative; COLOR: black; width:"+tmpv+"; FONT-FAMILY: tahoma; FONT-SIZE: 10pt; FONT-STYLE: normal; FONT-WEIGHT: bold; TEXT-DECORATION: none; LINE-HEIGHT: 6pt; text-align:justify;padding:0px;\"";

uzun="<div id=\"enuzun\" style=\"position:absolute;left:0;top:0;\">";
var uzunobj=null;
var uzuntop=0;
var toplay=0;

function mdivmo(gnum)
{
	inoout=true;

	if(linka[gnum].length != "" && (linka[gnum].length)>2)
	{
		objd=document.getElementById('d'+gnum);
		objd2=document.getElementById('hgd'+gnum);

		objd.style.color="#8E0606";
		objd2.style.color="#B90000";

		objd.style.cursor='pointer';
		objd2.style.cursor='pointer';

		objd.style.textDecoration='none';objd2.style.textDecoration='none';

		window.status=""+linka[gnum];
	}
}

function restime(gnum2)
{
	inoout=false;
	
	objd=document.getElementById('d'+gnum2);
	objd2=document.getElementById('hgd'+gnum2);

	objd.style.color="#000000";
	objd2.style.color="#414A76";

	objd.style.textDecoration='none';objd2.style.textDecoration='none';

	window.status="";
}

function butclick(gnum3)
{
if(linka[gnum3].substring(0,11)=="javascript:"){eval(""+linka[gnum3]);}else{if((linka[gnum3].length)>3){
if((trgfrma[gnum3].indexOf("_parent")>-1)){eval("parent.window.location='"+linka[gnum3]+"'");}else if((trgfrma[gnum3].indexOf("_top")>-1)){eval("top.window.location='"+linka[gnum3]+"'");}else{window.open(''+linka[gnum3],''+trgfrma[gnum3]);}}}

}

function dotrans()
{
	if(inoout==false){

	uzuntop--;
	if(uzuntop<(-1*toplay))
	{
		uzuntop=140;
	}

	uzunobj.style.top=uzuntop+"px";
}
	if(psy[(uzuntop*(-1))+4]==3)
	{
		setTimeout('dotrans()',2000+40);
	}
	else
	{
		setTimeout('dotrans()',40);
	}	
	
}


function initte2()
{
	i=0;
	for(i=0;i<mc;i++)
	{
	      
		  
		objd=document.getElementById('d'+i);
		
		heightarr[i]=objd.offsetHeight;
	}
	toplay=0;
	for(i=0;i<mc;i++)
	{
		objd=document.getElementById('d'+i);
		objd.style.visibility="visible";
		objd.style.top=""+toplay+"px";
		psy[toplay]=3;
		toplay=toplay+heightarr[i]+0;

	}

	uzunobj=document.getElementById('enuzun');
	uzunobj.style.left=8+"px";
	uzunobj.style.height=toplay+"px";
	uzunobj.style.width=tmpv+"px";
	uzuntop=140;
	dotrans();

}

function initte()
{
	i=0;
	innertxt=""+uzun;

	for(i=0;i<mc;i++)
	{
		innertxt=innertxt+""+divtextb+""+i+""+divtev1+i+divtev2+i+divtev3+i+divtev4+divtexts+"<div id=\"hgd"+i+"\""+ns6span+">"+titlea[i]+"</div>"+texta[i]+"</div>";
	}
	innertxt=innertxt+"</div>";
	spage=document.getElementById('spagens');

	spage.innerHTML=""+innertxt;

	spage.style.left="0px";
	spage.style.top="0px";

	setTimeout('initte2()',500);

}


window.onload=initte;